# codeBase 

#HOW TO

http://www.noahsarkeducation.com/code-lab/js/flexible-pagination 
